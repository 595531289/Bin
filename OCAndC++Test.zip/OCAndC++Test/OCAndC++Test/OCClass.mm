//
//  OCClass.m
//  OCAndC++Test
//
//  Created by 王斌 on 2018/10/26.
//  Copyright © 2018年 wangbin. All rights reserved.
//

#import "OCClass.h"
#import <Foundation/Foundation.h>

void objcSayHello(){
    NSLog(@"C++ 调用 OC");
}

