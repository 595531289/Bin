//
//  CPPHello.cpp
//  OCAndC++Test
//
//  Created by 王斌 on 2018/10/26.
//  Copyright © 2018年 wangbin. All rights reserved.
//

#include "CPPHello.hpp"
#include "OCClass.h"
void CPPHello::sayHello(){
    
    printf("OC调用了C++");

}
void CPPHello::sayGoodBye(){
    objcSayHello();

}

