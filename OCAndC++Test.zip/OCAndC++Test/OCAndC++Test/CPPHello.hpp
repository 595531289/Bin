//
//  CPPHello.hpp
//  OCAndC++Test
//
//  Created by 王斌 on 2018/10/26.
//  Copyright © 2018年 wangbin. All rights reserved.
//

#ifndef CPPHello_hpp
#define CPPHello_hpp

#include <stdio.h>

class CPPHello{
    
public:
    static void sayHello();
    static void sayGoodBye();
    
};

#endif /* CPPHello_hpp */
