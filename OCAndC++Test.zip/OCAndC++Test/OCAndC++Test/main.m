//
//  main.m
//  OCAndC++Test
//
//  Created by 王斌 on 2018/10/26.
//  Copyright © 2018年 wangbin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
