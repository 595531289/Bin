//
//  ViewController.m
//  OCAndC++Test
//
//  Created by 王斌 on 2018/10/26.
//  Copyright © 2018年 wangbin. All rights reserved.
//

#import "ViewController.h"
#import "CPPHello.hpp"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, 80, 40)];
    [btn setTitle:@"TestOC" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(OCAction) forControlEvents:UIControlEventTouchUpInside];
   
    UIButton *btn1 = [[UIButton alloc]initWithFrame:CGRectMake(100, 300, 80, 40)];
    [btn1 setTitle:@"TestC++" forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(CaddAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    [self.view addSubview:btn1];
}
- (void)OCAction{
    CPPHello::sayHello();
}
- (void)CaddAction{
    CPPHello::sayGoodBye();
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
